
ExifTool package for 64-bit Windows
___________________________________

Double-click on "exiftool(-k).exe" to read the application documentation, or
drag-and-drop files to extract metadata.

For command-line use, rename to "exiftool.exe".

Run directly in from the exiftool-##.##_64 folder, or copy the .exe and the
"exiftool_files" folder to wherever you want (preferably somewhere in your
PATH) to run from there.

See https://exiftool.org/install.html for more installation instructions.
